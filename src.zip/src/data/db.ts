import Dexie, { type Table } from "dexie";
import type { MemoryNode, MemoryEdge, Galaxy } from "../types/graph";

/** 每个星系的图数据,一行一个星系 */
export interface GraphRow {
  galaxyId: string; // 主键
  nodes: MemoryNode[];
  edges: MemoryEdge[];
}

/** 星系元信息表的行 */
export interface GalaxyRow extends Galaxy {}

/** 全局元数据(如当前激活星系)用键值对存 */
export interface MetaRow {
  key: string; // 主键,如 "activeGalaxyId"
  value: string;
}

export const DEFAULT_GALAXY_ID = "galaxy-default";

class AuraGraphDB extends Dexie {
  graph!: Table<GraphRow, string>;
  galaxies!: Table<GalaxyRow, string>;
  meta!: Table<MetaRow, string>;

  constructor() {
    super("aura-graph");

    // v1:旧结构(graph 表主键 "id",存一行 "current")
    this.version(1).stores({ graph: "id" });

    // v2:多星系结构
    this.version(2)
      .stores({
        graph: "galaxyId",
        galaxies: "id",
        meta: "key",
      })
      .upgrade(async (tx) => {
        const now = new Date().toISOString();
        const oldRows = await tx.table("graph").toArray();
        const current = oldRows.find(
          (r: { id?: string }) => r.id === "current"
        );

        await tx.table("galaxies").put({
          id: DEFAULT_GALAXY_ID,
          name: "My Universe",
          kind: "thought",
          accentColor: "#4f9dff",
          createdAt: now,
          updatedAt: now,
        });

        await tx.table("graph").put({
          galaxyId: DEFAULT_GALAXY_ID,
          nodes: current?.nodes ?? [],
          edges: current?.edges ?? [],
        });

        try {
          await tx.table("graph").delete("current");
        } catch {
          // 忽略:某些情况下旧行已被新结构覆盖
        }

        await tx.table("meta").put({
          key: "activeGalaxyId",
          value: DEFAULT_GALAXY_ID,
        });
      });

    this.graph = this.table("graph");
    this.galaxies = this.table("galaxies");
    this.meta = this.table("meta");
  }
}

export const db = new AuraGraphDB();
