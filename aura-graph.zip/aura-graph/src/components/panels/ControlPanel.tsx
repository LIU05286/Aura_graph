import { useMemo } from "react";
import { useGraphStore } from "../../store/graphStore";
import { getVisibleNodeIds } from "../../utils/graphFilter";
import SearchPanel from "./SearchPanel";
import TypeFilterPanel from "./TypeFilterPanel";
import TagFilterPanel from "./TagFilterPanel";

/** 左侧控制面板:品牌 + 搜索 + 类型筛选 + 星座筛选 + 状态行 */
export default function ControlPanel() {
  const nodes = useGraphStore((s) => s.nodes);
  const hiddenTypes = useGraphStore((s) => s.hiddenTypes);
  const activeTags = useGraphStore((s) => s.activeTags);

  const visibleCount = useMemo(
    () => getVisibleNodeIds(nodes, hiddenTypes, activeTags).size,
    [nodes, hiddenTypes, activeTags]
  );

  return (
    <div className="ag-panel ag-left">
      <div className="ag-brand">
        <span className="ag-brand-mark" />
        <div>
          <div className="ag-brand-name">AURA GRAPH</div>
          <div className="ag-brand-sub">memory universe</div>
        </div>
      </div>

      <SearchPanel />
      <TypeFilterPanel />
      <TagFilterPanel />

      <div className="ag-footer">
        当前可见 {visibleCount} 颗星 · 拖拽旋转 · 滚轮缩放 · 点击查看
      </div>
    </div>
  );
}
