import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles/global.css";
import "./styles/auraGraph.css";

const rootEl = document.getElementById("root");
if (!rootEl) throw new Error("缺少 #root 挂载点");

ReactDOM.createRoot(rootEl).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
