import type { MemoryNode } from "../types/graph";

export type Vec3 = [number, number, number];

/** 读取节点的 3D 坐标(渲染层统一从这里取,未来切换布局算法时只改这里) */
export function getNodePosition(node: MemoryNode): Vec3 {
  return [node.x, node.y, node.z];
}

/**
 * 预留:下一轮接入 d3-force-3d 时在此实现真正的力导布局。
 * 当前直接返回 seed 里已有的坐标,行为与原型一致(本轮不做自动布局)。
 */
export function computeLayout(nodes: MemoryNode[]): Map<string, Vec3> {
  const positions = new Map<string, Vec3>();
  for (const n of nodes) positions.set(n.id, [n.x, n.y, n.z]);
  return positions;
}
