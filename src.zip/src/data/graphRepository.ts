import type { AuraGraph, Galaxy } from "../types/graph";
import { apiGetData, apiPutData, type ServerDoc } from "../api/client";

export const DEFAULT_GALAXY_ID = "galaxy-default";

// 内存缓存整份服务器文档;读走缓存,写改缓存后整份 PUT 回服务器。
let cache: ServerDoc | null = null;
let loading: Promise<ServerDoc> | null = null;

function normalize(d: Partial<ServerDoc> | null | undefined): ServerDoc {
  return {
    galaxies: Array.isArray(d?.galaxies) ? (d!.galaxies as Galaxy[]) : [],
    activeGalaxyId: typeof d?.activeGalaxyId === "string" ? d!.activeGalaxyId : null,
    graphs:
      d?.graphs && typeof d.graphs === "object"
        ? (d!.graphs as Record<string, AuraGraph>)
        : {},
  };
}

async function ensureDoc(): Promise<ServerDoc> {
  if (cache) return cache;
  if (!loading) {
    loading = apiGetData()
      .then((d) => {
        cache = normalize(d);
        return cache;
      })
      .catch((e) => {
        loading = null; // 失败可重试
        throw e;
      });
  }
  return loading;
}

async function flush(): Promise<void> {
  if (cache) await apiPutData(cache);
}

export async function getActiveGalaxyId(): Promise<string> {
  const doc = await ensureDoc();
  return doc.activeGalaxyId ?? DEFAULT_GALAXY_ID;
}
export async function setActiveGalaxyId(id: string): Promise<void> {
  const doc = await ensureDoc();
  doc.activeGalaxyId = id;
  await flush();
}
export async function listGalaxies(): Promise<Galaxy[]> {
  const doc = await ensureDoc();
  return doc.galaxies;
}
export async function putGalaxy(galaxy: Galaxy): Promise<void> {
  const doc = await ensureDoc();
  const i = doc.galaxies.findIndex((g) => g.id === galaxy.id);
  if (i >= 0) doc.galaxies[i] = galaxy;
  else doc.galaxies.push(galaxy);
  await flush();
}
export async function deleteGalaxy(id: string): Promise<void> {
  const doc = await ensureDoc();
  doc.galaxies = doc.galaxies.filter((g) => g.id !== id);
  delete doc.graphs[id];
  await flush();
}
export async function loadGraphById(galaxyId: string): Promise<AuraGraph | null> {
  const doc = await ensureDoc();
  const g = doc.graphs[galaxyId];
  return g ? { nodes: g.nodes, edges: g.edges } : null;
}
export async function saveGraphById(galaxyId: string, graph: AuraGraph): Promise<void> {
  const doc = await ensureDoc();
  doc.graphs[galaxyId] = { nodes: graph.nodes, edges: graph.edges };
  await flush();
}
export async function loadGraph(): Promise<AuraGraph | null> {
  const id = await getActiveGalaxyId();
  return loadGraphById(id);
}
export async function saveGraph(graph: AuraGraph): Promise<void> {
  const id = await getActiveGalaxyId();
  await saveGraphById(id, graph);
}
