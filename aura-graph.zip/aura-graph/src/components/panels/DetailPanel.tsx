import { useMemo } from "react";
import { useGraphStore } from "../../store/graphStore";
import { getNodeById, getConnectedNodes } from "../../utils/graphRelations";
import { TYPE_LABEL } from "../../data/visualMappings";
import TypeDot from "../ui/TypeDot";
import Stars from "../ui/Stars";
import Chip from "../ui/Chip";

/** 右侧详情:选中节点的内容、星级、星座、关联节点(可点击跳转) */
export default function DetailPanel() {
  const nodes = useGraphStore((s) => s.nodes);
  const edges = useGraphStore((s) => s.edges);
  const selectedNodeId = useGraphStore((s) => s.selectedNodeId);
  const selectNode = useGraphStore((s) => s.selectNode);
  const requestFocusNode = useGraphStore((s) => s.requestFocusNode);

  const node = useMemo(
    () => getNodeById(nodes, selectedNodeId),
    [nodes, selectedNodeId]
  );
  const connected = useMemo(
    () => (node ? getConnectedNodes(nodes, edges, node.id) : []),
    [node, nodes, edges]
  );

  if (!node) return null;

  const pick = (id: string) => {
    selectNode(id);
    requestFocusNode(id);
  };

  return (
    <div className="ag-panel ag-right">
      <button className="ag-close" onClick={() => selectNode(null)} aria-label="关闭详情">
        ×
      </button>

      <div className="ag-detail-type">
        <TypeDot type={node.type} />
        {TYPE_LABEL[node.type]}
      </div>
      <h2 className="ag-detail-title">{node.title}</h2>
      <Stars value={node.importance} />
      <p className="ag-detail-content">{node.content}</p>

      {node.tags.length > 0 && (
        <div className="ag-detail-block">
          <div className="ag-eyebrow">星座</div>
          <div className="ag-chips">
            {node.tags.map((t) => (
              <Chip key={t} tag isStatic>
                #{t}
              </Chip>
            ))}
          </div>
        </div>
      )}

      {connected.length > 0 && (
        <div className="ag-detail-block">
          <div className="ag-eyebrow">关联的星 ({connected.length})</div>
          <div className="ag-connected">
            {connected.map((n) => (
              <button key={n.id} className="ag-result" onClick={() => pick(n.id)}>
                <TypeDot type={n.type} />
                <span className="ag-result-title">{n.title}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
